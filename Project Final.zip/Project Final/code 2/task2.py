import sys


def read_log_file(filename):
    try:
        with open(filename, 'r') as file:
            return file.readlines()
    except FileNotFoundError:
        print(f'Error: The file "{filename}" could not be found!')
        sys.exit(1)

def analyze_log(log_lines):
    cat_visits, other_cats, total_time_in_house, durations = 0, 0, 0, []

    for line in log_lines:
        if line.strip() == 'END':
            break

        cat_type, entry_time, exit_time = map(str.strip, line.split(','))

        entry_time, exit_time = int(entry_time), int(exit_time)

        if cat_type == 'OURS':
            cat_visits += 1
            time_spent = exit_time - entry_time
            total_time_in_house += time_spent
            durations.append(time_spent)
        elif cat_type == 'THEIRS':
            other_cats += 1

    return cat_visits, other_cats, total_time_in_house, durations

def format_time(minutes):
    hours, remaining_minutes = divmod(minutes, 60)
    return f'{hours} Hours, {remaining_minutes} Minutes'

def main():
    if len(sys.argv) != 2:
        print('Usage: python script.py <filename>')
        sys.exit(1)

    filename = sys.argv[1]
    log_lines = read_log_file(filename)

    cat_visits, other_cats, total_time, durations = analyze_log(log_lines)

    print('\nLog File Analysis\n' + '=' * 18 + '\n')
    print(f'Number of Cat Visits: {cat_visits}')
    print(f'Number of Other Cats: {other_cats}')
    print(f'Total Time Spent in House: {format_time(total_time)}', end='\n\n')

    if cat_visits > 0:
        average_duration = sum(durations) / len(durations)
        longest_duration, shortest_duration = max(durations), min(durations)

        print(f'Average Visit Duration: {int(average_duration)} Minutes')
        print(f'Longest Visit Duration: {longest_duration} Minutes')
        print(f'Shortest Visit Duration: {shortest_duration} Minutes')

if __name__ == "__main__":
    main()
