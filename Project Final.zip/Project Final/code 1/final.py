def positive_integer_input(a):
    while True:
        try:
            value = int(input(a))
            if value > 0:
                return value
            else:
                print("Please enter a positive integer!")
        except ValueError:
            print("Please enter a number!")
        

def yes_no_input(a):
    while True:
        response = input(a).strip().lower()
        if response == 'y' or response == 'n':
            return response == 'y'
        else:
            print('Please answer "Y" or "N".')

def calculate_pizza_price(tuesday, num_pizzas, delivery, app_order):
    # Constants
    PIZZA_PRICE = 12.00
    DELIVERY_COST = 2.50
    APP_DISCOUNT = 0.25

    # Apply Tuesday discount

    if tuesday:
        total_price = num_pizzas * (PIZZA_PRICE / 2)
    else:
        total_price = num_pizzas * PIZZA_PRICE

    # Apply free delivery for five or more pizzas
    if num_pizzas >= 5 and delivery:
        delivery_cost = 0.00
    elif delivery:
        delivery_cost = DELIVERY_COST
    else:
        delivery_cost = 0.00

    # Calculate total price before app discount
    total_price += delivery_cost

    # Apply app discount
    if app_order:
        total_price *= (1 - APP_DISCOUNT)

    return round(total_price, 2)

def main():
    print("BPP Pizza Price Calculator")
    print("==========================")

    # Gather user input with input validation
    num_pizzas = positive_integer_input("How many pizzas ordered? ")
    delivery = yes_no_input("Is delivery required? (Y/N) ")
    tuesday = yes_no_input("Is it Tuesday? (Y/N) ")
    app_order = yes_no_input("Did the customer use the app? (Y/N) ")

    # Calculate and display the total price
    total_price = calculate_pizza_price(tuesday, num_pizzas, delivery, app_order)
    print(f'Total Price: £{total_price:.2f}')


if __name__ == "__main__":
    main()
