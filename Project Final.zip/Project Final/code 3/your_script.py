PASSWORD_FILE = "passwd.txt"

def read_password_file():
    with open(PASSWORD_FILE, "r") as file:
        lines = file.readlines()
    return [line.strip() for line in lines]

def write_password_file(data):
    with open(PASSWORD_FILE, "w") as file:
        file.write("\n".join(data))

def encrypt_password(password):
    # You can use a more secure encryption method if needed
    return password[::-1]

def adduser():
    username = input("Enter new username: ").lower()
    real_name = input("Enter real name: ")
    password = input("Enter password: ")

    data = read_password_file()
    for line in data:
        if line.startswith(username + ":"):
            print("Error: User already exists.")
            return

    encrypted_password = encrypt_password(password)
    data.append(f"{username}:{real_name}:{encrypted_password}")
    write_password_file(data)
    print("User Created.")

def deluser():
    username = input("Enter username to delete: ").lower()

    data = read_password_file()
    new_data = [line for line in data if not line.startswith(username + ":")]
    if len(new_data) == len(data):
        print("Nothing changed. User not found.")
    else:
        write_password_file(new_data)
        print("User Deleted.")

def passwd():
    username = input("Enter username: ").lower()
    current_password = input("Enter current password: ")
    new_password = input("Enter new password: ")
    confirm_password = input("Enter new password again: ")

    data = read_password_file()
    for i, line in enumerate(data):
        if line.startswith(username + ":"):
            _, _, stored_password = line.split(":")
            if current_password == encrypt_password(stored_password) and new_password == confirm_password:
                data[i] = f"{username}:{line.split(':')[1]}:{encrypt_password(new_password)}"
                write_password_file(data)
                print("Password Changed.")
                return

    print("No change. Username or current password incorrect, or passwords do not match.")

def login():
    username = input("Enter username: ").lower()
    password = input("Enter password: ")

    data = read_password_file()
    for line in data:
        if line.startswith(username + ":"):
            _, _, stored_password = line.split(":")
            if password == encrypt_password(stored_password):
                print("Access Granted.")
                return

    print("Access Denied.")

# Example usage
# adduser()
# deluser()
# passwd()
# login()
