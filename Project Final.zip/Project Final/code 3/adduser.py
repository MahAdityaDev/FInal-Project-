# adduser.py

from your_script import adduser

if __name__ == "__main__":
    adduser()
