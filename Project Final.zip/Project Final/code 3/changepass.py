# changepassword.py

from your_script import passwd

if __name__ == "__main__":
    passwd()
