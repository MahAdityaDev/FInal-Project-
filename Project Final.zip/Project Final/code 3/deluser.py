# deluser.py

from your_script import deluser

if __name__ == "__main__":
    deluser()
